function recordAllAnswers(e)
{
  var n=["q0"],t=document.querySelectorAll("input:checked");
  for(i=0;i<t.length&&(n.push(t[i].value),t[i]!=e);i++);
  return n
}

function renderQuestions(e)
{
  hideAllQuestions(),showQuestions(e),setTimeout(function()
  {
    var i=e.pop(),n=document.getElementById(i).offsetTop;
    $("html, body").animate({scrollTop:n-200})},50)
  }

  function showQuestions(e)
  {
    for(i=0;i<e.length;i++)
    document.getElementById(e[i]).className="visible";
    var n=document.querySelectorAll(".hidden input");
    for(i=0;i<n.length;i++)n[i].checked=!1
  }

  function hideAllQuestions()
  {
    var e=document.querySelectorAll(".hidden, .visible");
    for(i=0;i<e.length;i++)
    e[i].className="hidden"
  }
  var inputs=document.querySelectorAll(".decision-tree input[type=radio]");
  for(i=0;i<inputs.length;i++)
  inputs[i].addEventListener("click",function(e){e||(e=window.event);
    var i=recordAllAnswers(e.target);renderQuestions(i)});
